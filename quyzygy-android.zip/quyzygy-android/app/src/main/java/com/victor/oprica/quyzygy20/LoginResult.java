package com.victor.oprica.quyzygy20;

public class LoginResult {
    public String UserType;
    public String Key;
}
